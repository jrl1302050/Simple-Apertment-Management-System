<?php
$dbservername = "localhost";
$dbusername = "root";
$dbpassword = "";
$dbname = "apartment";
$conn=mysqli_connect($dbservername,$dbusername,$dbpassword,$dbname);

?>