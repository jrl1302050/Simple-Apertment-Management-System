<?php
session_start();
if(isset($_SESSION['usrid']))
{
	echo "";
}
else
{
	header ('location:userlogin.php');
}?>

<?php
include('header.php');
?>
<html>
<head>
<title>User dash</title>
<h1 align="center">Welcome to User Dashboard</h1>
</head>
<body background="b.jpg">
<a href="logout.php" style="float:right; margin-right:30px; color:#fff; font-size:20px;">log out</a>
<table align="center">
<h3><a href="userprofil.php" style="color:dodgeblue;">View profile</a></h3>
<h3><a href="bill.php" style="color:dodgeblue;">Pay Bill</a></h3>
<h3><a href="complains.php" style="color:dodgeblue;">Add Complain</a></h3>
</table>
</body>
</html>