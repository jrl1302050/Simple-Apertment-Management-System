<html>
<head>
<title>view</title>
<h1>View Notification</h1>
</head>
<body background="images/livingroom.jpg">
<h3><a href="confirm.php" style="color:dodgeblue;">Confirm Request</a></h3>
<h3><a href="dis_bill.php" style="color:dodgeblue;">Bills Payment</a></h3>
<h3><a href="dis_complain.php" style="color:dodgeblue;">Complain</a></h3>
<a href="logout.php">Log Out</a>
</body>
</html>
