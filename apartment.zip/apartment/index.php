<?php
include_once 'dbcon.php';
?>
<html>
<head>
<title>HOME PAGE</title>

</head>
<body  background="sap.jpg">
<h1 align="center">WELCOME TO APARTMENT MANAGEMENT SYSTEM</h>
<h3><a href="apartmentdetails.php" style="color:tomato;">Apartment Details</a></h3>
<h3><a href="admin.php"style="color:tomato;">Admin Login</a></h3>
<h3><a href="userlogin.php"style="color:tomato;">User Login</a></h3>
</body>
</html>




